<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Assignment Submission</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f9;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 80px auto;
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
    }

    label {
      display: block;
      margin-top: 15px;
      color: #555;
      font-weight: bold;
    }

    input, select, textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
      margin-top: 5px;
    }

    button {
      display: block;
      width: 100%;
      background: #007BFF;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      margin-top: 20px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .success-message {
      color: green;
      text-align: center;
      margin-top: 20px;
      font-weight: bold;
      display: none;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Assignment Submission Form</h2>
    <form id="assignmentForm">
      <label for="name">Student Name:</label>
      <input type="text" id="name" name="name" required />

      <label for="roll">Roll Number:</label>
      <input type="text" id="roll" name="roll" required />

      <label for="subject">Subject:</label>
      <select id="subject" name="subject" required>
        <option value="">Select Subject</option>
        <option value="Math">Math</option>
        <option value="Science">Science</option>
        <option value="English">English</option>
        <option value="History">History</option>
      </select>

      <label for="assignment">Upload Assignment (PDF/DOC):</label>
      <input type="file" id="assignment" name="assignment" accept=".pdf,.doc,.docx" required />

      <label for="remarks">Remarks (optional):</label>
      <textarea id="remarks" name="remarks" placeholder="Add any comments..."></textarea>

      <button type="submit">Submit Assignment</button>
      <div class="success-message" id="successMessage">✅ Assignment submitted successfully!</div>
    </form>
  </div>

  <script>
    const form = document.getElementById('assignmentForm');
    const successMsg = document.getElementById('successMessage');

    form.addEventListener('submit', function(e) {
      e.preventDefault();

      const formData = new FormData(form);
      const data = Object.fromEntries(formData.entries());
      console.log('Assignment Data:', data);

      // Here you would send data to backend with fetch()
      // Example: fetch('/submit-assignment', { method: 'POST', body: formData });

      successMsg.style.display = 'block';
      form.reset();
    });
  </script>

</body>
</html>
