<?php
include("connection.php");

$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect and sanitize input values
    $studentname    = mysqli_real_escape_string($conn, $_POST["student_name"]);
    $gender         = mysqli_real_escape_string($conn, $_POST["gender"]);
    $dateofbirth    = mysqli_real_escape_string($conn, $_POST["dob"]);
    $gradeappliedof = mysqli_real_escape_string($conn, $_POST["grade_applied"]);
    $email          = mysqli_real_escape_string($conn, $_POST["email"]);
    $phone          = mysqli_real_escape_string($conn, $_POST["phone"]);
    $address        = mysqli_real_escape_string($conn, $_POST["address"]);

    // Correct SQL query
    $sql = "INSERT INTO `logins`
            (`Student Name`, `Gender`, `Date of  Birth`, `Grade Applied of`, `Email`, `Phone`, `Address`)
            VALUES 
            ('$studentname', '$gender', '$dateofbirth', '$gradeappliedof', '$email', '$phone', '$address')";

    if (mysqli_query($conn, $sql)) {
        $msg = "Data inserted successfully!";
    } else {
        $msg = "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);

    echo $msg;
}
?>

























<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>School Admission Form</title>
    <style>
        body { font-family: Arial; background: #f2f2f2; padding: 20px; }
        form { background: white; padding: 20px; border-radius: 5px; width: 400px; margin: auto; }
        input, select, textarea { width: 100%; padding: 10px; margin: 5px 0; }
        button { background: #4CAF50; color: white; padding: 10px; border: none; cursor: pointer; width: 100%; }
        button:hover { background: #45a049; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">School Admission Form</h2>
    <form action="admission.php" method="POST">
        <label>Student Name:</label>
        <input type="text" name="student_name" required>

        <label>Gender:</label>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option>Male</option>
            <option>Female</option>
        </select>

        <label>Date of  Birth:</label>
        <input type="date" name="dob" required>

        <label>Grade Applied For:</label>
        <input type="text" name="grade_applied" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Phone:</label>
        <input type="text" name="phone" required>

        <label>Address:</label>
        <textarea name="address" rows="4" required></textarea>

        <button type="submit">Submit Application</button>
    </form>
</body>
</html>
