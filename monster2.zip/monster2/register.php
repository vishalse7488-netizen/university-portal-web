<?php
include("connection.php");

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["name"];
    $email    = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, email, password)
            VALUES ('$username', '$email', '$password')";

    if (mysqli_query($conn, $sql)) {
        $msg = "✅ Account created successfully!";
    } else {
        $msg = "❌ Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Account</title>
<link rel="stylesheet" href="css/bootstrap.min.css">

<style>
body{
  height:100vh;
  display:flex;
  justify-content:center;
  align-items:center;
  background:linear-gradient(135deg,#667eea,#764ba2);
  font-family:'Poppins',sans-serif;
}

.signup-box{
  width:380px;
  padding:35px;
  border-radius:15px;
  background:rgba(255,255,255,0.15);
  backdrop-filter:blur(12px);
  box-shadow:0 20px 40px rgba(0,0,0,0.25);
  color:#fff;
  animation:fadeIn .8s ease;
}

@keyframes fadeIn{
  from{opacity:0; transform:translateY(-20px);}
  to{opacity:1; transform:translateY(0);}
}

.signup-box h3{
  text-align:center;
  margin-bottom:25px;
  font-weight:600;
}

.form-control{
  border-radius:10px;
  border:none;
  padding:10px 12px;
}

.form-control:focus{
  box-shadow:0 0 8px rgba(255,255,255,.6);
}

.btn-custom{
  background:linear-gradient(90deg,#ff512f,#dd2476);
  border:none;
  border-radius:10px;
  padding:12px;
  font-weight:500;
  transition:.3s;
}

.btn-custom:hover{
  transform:translateY(-2px);
  opacity:.9;
}

.msg{
  background:rgba(0,0,0,.3);
  padding:8px;
  border-radius:8px;
  text-align:center;
  margin-bottom:15px;
  font-size:14px;
}

.footer-text{
  text-align:center;
  margin-top:15px;
  font-size:14px;
}

.footer-text a{
  color:#ffeaa7;
  text-decoration:none;
}

.footer-text a:hover{
  text-decoration:underline;
}
</style>
</head>

<body>

<form method="post">
  <div class="signup-box">
    <h3>Create Account</h3>

    <?php if($msg!=""){ ?>
      <div class="msg"><?php echo $msg; ?></div>
    <?php } ?>

    <div class="mb-3">
      <label>Name</label>
      <input type="text" name="name" class="form-control" required>
    </div>

    <div class="mb-3">
      <label>Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
      <label>Password</label>
      <input type="password" name="password" class="form-control" required minlength="6">
    </div>

    <button class="btn btn-custom w-100">Sign Up</button>

    <div class="footer-text">
      Already have an account? <a href="login.php">Login</a>
    </div>
  </div>
</form>

</body>
</html>
