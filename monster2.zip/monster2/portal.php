<?php
include("connection.php");

$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

$records = mysqli_query($conn, "SELECT s.name, a.status 
                                FROM students s
                                LEFT JOIN attendance a ON s.id = a.student_id AND a.date='$date'");
?>

<h2>Attendance on <?php echo $date; ?></h2>
<form method="GET">
    <input type="date" name="date" value="<?php echo $date; ?>">
    <button type="submit">View</button>
</form>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Student Name</th>
        <th>Status</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($records)) { ?>
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['status'] ?? 'Absent'; ?></td>
        </tr>
    <?php } ?>
</table>
