<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Health Record Page</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6fa;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 700px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
    }

    label {
      display: block;
      margin: 12px 0 5px;
      font-weight: bold;
      color: #444;
    }

    input, select, textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    textarea {
      resize: vertical;
    }

    button {
      display: block;
      width: 100%;
      background: #007BFF;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      margin-top: 20px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .record-box {
      margin-top: 30px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 5px;
      border: 1px solid #ddd;
      display: none;
    }

    .record-box h3 {
      color: #007BFF;
      margin-bottom: 10px;
    }

    .record-box p {
      margin: 6px 0;
      color: #333;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Health Record Form</h2>
    <form id="healthForm">
      <label for="name">Patient Name:</label>
      <input type="text" id="name" required>

      <label for="age">Age:</label>
      <input type="number" id="age" required>

      <label for="gender">Gender:</label>
      <select id="gender" required>
        <option value="">Select Gender</option>
        <option>Male</option>
        <option>Female</option>
        <option>Other</option>
      </select>

      <label for="blood">Blood Group:</label>
      <input type="text" id="blood" placeholder="e.g., O+, A-, B+" required>

      <label for="condition">Medical Condition:</label>
      <textarea id="condition" placeholder="Describe health condition..." required></textarea>

      <label for="medicine">Prescribed Medicines:</label>
      <textarea id="medicine" placeholder="List of medicines..."></textarea>

      <label for="doctor">Doctor's Name:</label>
      <input type="text" id="doctor" required>

      <button type="submit">Save Record</button>
    </form>

    <div class="record-box" id="recordBox">
      <h3>Saved Health Record</h3>
      <p><strong>Patient Name:</strong> <span id="rName"></span></p>
      <p><strong>Age:</strong> <span id="rAge"></span></p>
      <p><strong>Gender:</strong> <span id="rGender"></span></p>
      <p><strong>Blood Group:</strong> <span id="rBlood"></span></p>
      <p><strong>Condition:</strong> <span id="rCondition"></span></p>
      <p><strong>Medicines:</strong> <span id="rMedicine"></span></p>
      <p><strong>Doctor:</strong> <span id="rDoctor"></span></p>
    </div>
  </div>

  <script>
    const form = document.getElementById('healthForm');
    const recordBox = document.getElementById('recordBox');

    form.addEventListener('submit', function(e) {
      e.preventDefault();

      // Get form data
      document.getElementById('rName').textContent = document.getElementById('name').value;
      document.getElementById('rAge').textContent = document.getElementById('age').value;
      document.getElementById('rGender').textContent = document.getElementById('gender').value;
      document.getElementById('rBlood').textContent = document.getElementById('blood').value;
      document.getElementById('rCondition').textContent = document.getElementById('condition').value;
      document.getElementById('rMedicine').textContent = document.getElementById('medicine').value || 'None';
      document.getElementById('rDoctor').textContent = document.getElementById('doctor').value;

      // Show record
      recordBox.style.display = 'block';
      form.reset();
    });
  </script>
</body>
</html>
