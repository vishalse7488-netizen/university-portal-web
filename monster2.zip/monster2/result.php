<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Result Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f9;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 80px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
    }

    label {
      display: block;
      margin: 15px 0 5px;
      font-weight: bold;
      color: #555;
    }

    input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    button {
      display: block;
      width: 100%;
      margin-top: 20px;
      background: #007BFF;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .result-box {
      margin-top: 25px;
      background: #f9f9f9;
      border: 1px solid #ddd;
      padding: 20px;
      border-radius: 5px;
      display: none;
    }

    .result-box h3 {
      margin-bottom: 10px;
      color: #333;
    }

    .marks {
      color: #007BFF;
      font-weight: bold;
    }

    .grade {
      font-weight: bold;
    }

    .grade.pass { color: green; }
    .grade.fail { color: red; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Check Your Result</h2>
    <label for="rollNumber">Enter Roll Number:</label>
    <input type="text" id="rollNumber" placeholder="e.g. 101" required />
    <button onclick="getResult()">View Result</button>

    <div class="result-box" id="resultBox">
      <h3 id="studentName"></h3>
      <p>Math: <span class="marks" id="mathMarks"></span></p>
      <p>Science: <span class="marks" id="scienceMarks"></span></p>
      <p>English: <span class="marks" id="englishMarks"></span></p>
      <p>Total: <span class="marks" id="totalMarks"></span></p>
      <p>Grade: <span class="grade" id="grade"></span></p>
    </div>
  </div>

  <script>
    // Sample student data (this would come from a database in real use)
    const studentResults = {
      101: { name: "Alice Johnson", math: 85, science: 90, english: 78 },
      102: { name: "Bob Smith", math: 55, science: 60, english: 58 },
      103: { name: "Charlie Brown", math: 95, science: 88, english: 92 }
    };

    function getResult() {
      const roll = document.getElementById("rollNumber").value.trim();
      const resultBox = document.getElementById("resultBox");

      if (!roll) {
        alert("Please enter your roll number!");
        return;
      }

      const student = studentResults[roll];
      if (!student) {
        alert("Result not found for this roll number!");
        resultBox.style.display = "none";
        return;
      }

      // Calculate total and grade
      const total = student.math + student.science + student.english;
      const avg = total / 3;
      const grade = avg >= 60 ? "Pass" : "Fail";

      // Display result
      document.getElementById("studentName").textContent = student.name;
      document.getElementById("mathMarks").textContent = student.math;
      document.getElementById("scienceMarks").textContent = student.science;
      document.getElementById("englishMarks").textContent = student.english;
      document.getElementById("totalMarks").textContent = total;
      document.getElementById("grade").textContent = grade;
      document.getElementById("grade").className = grade === "Pass" ? "grade pass" : "grade fail";
      resultBox.style.display = "block";
    }
  </script>
</body>
</html>
