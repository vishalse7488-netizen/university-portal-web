<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Attendance Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f9;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 800px;
      margin: 50px auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: center;
    }

    th {
      background: #007BFF;
      color: white;
    }

    button {
      background: #007BFF;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 20px;
    }

    button:hover {
      background: #0056b3;
    }

    .present { color: green; font-weight: bold; }
    .absent { color: red; font-weight: bold; }
  </style>
</head>
<body>

  <div class="container">
    <h2>Student Attendance</h2>
    <table id="attendanceTable">
      <thead>
        <tr>
          <th>Roll No</th>
          <th>Name</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>suraj singh</td>
          <td id="status-1">Not Marked</td>
          <td>
            <button onclick="markAttendance(1, 'Present')">Present</button>
            <button onclick="markAttendance(1, 'Absent')">Absent</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>manav singh</td>
          <td id="status-2">Not Marked</td>
          <td>
            <button onclick="markAttendance(2, 'Present')">Present</button>
            <button onclick="markAttendance(2, 'Absent')">Absent</button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td>shivam gupta</td>
          <td id="status-3">Not Marked</td>
          <td>
            <button onclick="markAttendance(3, 'Present')">Present</button>
            <button onclick="markAttendance(3, 'Absent')">Absent</button>
          </td>
        </tr>
      </tbody>
    </table>

    <button onclick="saveAttendance()">Save Attendance</button>
  </div>

  <script>
    const attendance = {};

    function markAttendance(id, status) {
      attendance[id] = status;
      const statusCell = document.getElementById(`status-${id}`);
      statusCell.textContent = status;
      statusCell.className = status === 'Present' ? 'present' : 'absent';
    }

    function saveAttendance() {
      if (Object.keys(attendance).length === 0) {
        alert('No attendance marked!');
        return;
      }
      console.log('Attendance data:', attendance);
      alert('Attendance saved successfully!');
      // You could send this data to a backend using fetch() or AJAX here
    }
  </script>

</body>
</html>
