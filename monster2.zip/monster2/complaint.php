<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullname       = mysqli_real_escape_string($conn, $_POST['name']);
    $emailaddress   = mysqli_real_escape_string($conn, $_POST['email']);
    $subject        = mysqli_real_escape_string($conn, $_POST['subject']);
    $message        = mysqli_real_escape_string($conn, $_POST['message']);

    $sql = "INSERT INTO complaint (`full name`, `email address`, `subject`, `complaint details`)
            VALUES ('$fullname', '$emailaddress', '$subject', '$message')";

    if (mysqli_query($conn, $sql)) {
        echo "<h2>Complaint submitted successfully!</h2>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
























<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Complaint Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 600px;
      margin: 80px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
    }

    label {
      display: block;
      margin: 15px 0 5px;
      color: #555;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    textarea {
      height: 120px;
      resize: vertical;
    }

    button {
      display: block;
      width: 100%;
      padding: 12px;
      background: #007BFF;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      margin-top: 20px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Submit a Complaint</h2>
    <form action="complaint.php" method="POST">
      <label for="name">Full Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="email">Email Address:</label>
      <input type="email" id="email" name="email" required>

      <label for="subject">Subject:</label>
      <input type="text" id="subject" name="subject" required>

      <label for="message">Complaint Details:</label>
      <textarea id="message" name="message" required></textarea>

      <button type="submit">Submit Complaint</button>
    </form>
  </div>

</body>
</html>
