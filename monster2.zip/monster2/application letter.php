<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Application Letter Generator</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6fa;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 700px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
    }

    label {
      display: block;
      margin: 12px 0 5px;
      font-weight: bold;
      color: #444;
    }

    input, textarea, select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    textarea {
      resize: vertical;
    }

    button {
      display: block;
      width: 100%;
      background: #007BFF;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      margin-top: 20px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .letter-box {
      margin-top: 30px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 5px;
      border: 1px solid #ddd;
      display: none;
      white-space: pre-line;
    }

    .letter-box h3 {
      color: #007BFF;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Application Letter Generator</h2>

    <form id="letterForm">
      <label for="name">Your Full Name:</label>
      <input type="text" id="name" placeholder="e.g., John Doe" required>

      <label for="address">Your Address:</label>
      <textarea id="address" placeholder="Enter your address..." required></textarea>

      <label for="date">Date:</label>
      <input type="date" id="date" required>

      <label for="receiver">Recipient (e.g., The Principal):</label>
      <input type="text" id="receiver" placeholder="e.g., The Principal" required>

      <label for="school">Institution/Company Name:</label>
      <input type="text" id="school" placeholder="e.g., ABC High School" required>

      <label for="subject">Subject:</label>
      <input type="text" id="subject" placeholder="e.g., Application for Leave" required>

      <label for="body">Reason/Body of the Letter:</label>
      <textarea id="body" placeholder="Write your message here..." required></textarea>

      <button type="submit">Generate Letter</button>
    </form>

    <div class="letter-box" id="letterBox">
      <h3>Generated Application Letter</h3>
      <div id="letterContent"></div>
    </div>
  </div>

  <script>
    const form = document.getElementById('letterForm');
    const letterBox = document.getElementById('letterBox');
    const letterContent = document.getElementById('letterContent');

    form.addEventListener('submit', function(e) {
      e.preventDefault();

      const name = document.getElementById('name').value;
      const address = document.getElementById('address').value;
      const date = document.getElementById('date').value;
      const receiver = document.getElementById('receiver').value;
      const school = document.getElementById('school').value;
      const subject = document.getElementById('subject').value;
      const body = document.getElementById('body').value;

      const letter = `
${address}

Date: ${date}

To,  
${receiver},  
${school}.  

Subject: ${subject}  

Respected Sir/Madam,  

${body}

Thank you for your kind consideration.

Yours sincerely,  
${name}
      `;

      letterContent.textContent = letter;
      letterBox.style.display = 'block';
      form.reset();
    });
  </script>

</body>
</html>
